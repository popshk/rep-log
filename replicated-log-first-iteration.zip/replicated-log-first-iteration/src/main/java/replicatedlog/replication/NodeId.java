package replicatedlog.replication;

public record NodeId(String id) {
}
