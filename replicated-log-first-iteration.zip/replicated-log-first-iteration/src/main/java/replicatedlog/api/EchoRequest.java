package replicatedlog.api;

public record EchoRequest(String text) {
}
