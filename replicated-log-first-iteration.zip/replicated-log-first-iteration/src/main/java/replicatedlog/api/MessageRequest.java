package replicatedlog.api;

public record MessageRequest(String text) {
}
