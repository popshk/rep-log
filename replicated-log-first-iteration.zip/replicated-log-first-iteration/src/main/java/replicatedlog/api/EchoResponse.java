package replicatedlog.api;

public record EchoResponse(String text) {
}
