package replicatedlog.config;

public enum NodeRole {
    MASTER,
    SECONDARY
}
